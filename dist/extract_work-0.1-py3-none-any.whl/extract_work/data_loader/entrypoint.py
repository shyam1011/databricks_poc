import data_loader

if __name__ == "__main__":
    print("Starting Databricks Jobs")
    data_loader.main()
